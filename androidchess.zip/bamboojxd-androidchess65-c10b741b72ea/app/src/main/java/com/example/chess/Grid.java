package com.example.chess;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

@SuppressLint("ViewConstructor")
public class Grid extends View
{
	public int col;
	public int row;

	public Grid(Context context, int ID)
	{
		super(context);
		setId(generateViewId());

		this.col = ID % 8;
		this.row = ID / 8;

		setBackgroundColor((row + col) % 2 == 0 ? KTLib.HighColor : KTLib.LightColor);
	}

	public void Recover()
	{
		setBackgroundColor((row + col) % 2 == 0 ? KTLib.HighColor : KTLib.LightColor);
	}

	public void SetSelected(int fill)
	{
		int strokeWidth = 1; // 3dp 边框宽度
		int roundRadius = 15; // 8dp 圆角半径
		int strokeColor = KTLib.Border;//边框颜色

		GradientDrawable gd = new GradientDrawable();//创建drawable
		gd.setColor(fill);
		gd.setCornerRadius(roundRadius);
		gd.setStroke(strokeWidth, strokeColor);
		setBackground(gd);
	}
}