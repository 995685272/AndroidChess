package com.example.chess;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import static android.view.View.generateViewId;

public class MainActivity extends AppCompatActivity
{
	ConstraintLayout kLayout;
	Database kDB;

	ListView kList;
	Button kTimeButton;
	Button kTitleButton;
	Button kNewGameButton;

	ArrayList<Record> kRecords = new ArrayList<>();

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.activity_main);

		kLayout = findViewById(R.id.SuperLayout);
		kDB = new Database(getBaseContext());
	}

	@Override
	protected void onResume()
	{
		super.onResume();
		AddTable();

		ResetTable(true);
	}

	private void AddTable()
	{
		kLayout.removeAllViews();
		DisplayMetrics DM = KTLib.GetMetrics(this);

		kList = new ListView(this);
		kList.setId(generateViewId());
		kLayout.addView(kList, DM.widthPixels, DM.heightPixels - 200);

		kTimeButton = new Button(this);
		kTimeButton.setId(generateViewId());
		kTimeButton.setOnClickListener(OnSort);
		kTimeButton.setText(R.string.SortByTime);
		kTimeButton.setTypeface(null, Typeface.BOLD);
		kTimeButton.setTextSize(12);
		kTimeButton.setGravity(Gravity.CENTER);
		kTimeButton.setBackgroundColor(KTLib.Blue);
		kTimeButton.setAllCaps(false);
		kLayout.addView(kTimeButton, (DM.widthPixels - 200) / 3, 100);

		kTitleButton = new Button(this);
		kTitleButton.setId(generateViewId());
		kTitleButton.setOnClickListener(OnSort);
		kTitleButton.setText(R.string.SortByTitle);
		kTitleButton.setTypeface(null, Typeface.BOLD);
		kTitleButton.setTextSize(12);
		kTitleButton.setGravity(Gravity.CENTER);
		kTitleButton.setBackgroundColor(KTLib.Blue);
		kTitleButton.setAllCaps(false);
		kLayout.addView(kTitleButton, (DM.widthPixels - 200) / 3, 100);

		kNewGameButton = new Button(this);
		kNewGameButton.setId(generateViewId());
		kNewGameButton.setOnClickListener(OnNewGame);
		kNewGameButton.setText(R.string.NewGame);
		kNewGameButton.setTypeface(null, Typeface.BOLD);
		kNewGameButton.setTextSize(12);
		kNewGameButton.setGravity(Gravity.CENTER);
		kNewGameButton.setBackgroundColor(KTLib.Blue);
		kNewGameButton.setAllCaps(false);
		kLayout.addView(kNewGameButton, (DM.widthPixels - 200) / 3, 100);

		ConstraintSet set = new ConstraintSet();
		set.clone(kLayout);

		set.connect(kList.getId(), ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START);
		set.connect(kList.getId(), ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP);

		set.connect(kTimeButton.getId(), ConstraintSet.LEFT, kList.getId(), ConstraintSet.LEFT);
		set.connect(kTimeButton.getId(), ConstraintSet.TOP, kList.getId(), ConstraintSet.BOTTOM);
		set.setMargin(kTimeButton.getId(), 1, 50);
		set.setMargin(kTimeButton.getId(), 3, 50);

		set.connect(kTitleButton.getId(), ConstraintSet.LEFT, kTimeButton.getId(), ConstraintSet.RIGHT);
		set.connect(kTitleButton.getId(), ConstraintSet.TOP, kList.getId(), ConstraintSet.BOTTOM);
		set.setMargin(kTitleButton.getId(), 1, 50);
		set.setMargin(kTitleButton.getId(), 3, 50);

		set.connect(kNewGameButton.getId(), ConstraintSet.LEFT, kTitleButton.getId(), ConstraintSet.RIGHT);
		set.connect(kNewGameButton.getId(), ConstraintSet.TOP, kList.getId(), ConstraintSet.BOTTOM);
		set.setMargin(kNewGameButton.getId(), 1, 50);
		set.setMargin(kNewGameButton.getId(), 3, 50);

		set.applyTo(kLayout);
	}

	private final View.OnClickListener OnSort = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			ResetTable(view.getId() == kTimeButton.getId());
		}
	};

	private final View.OnClickListener OnNewGame = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			Intent intent = new Intent(MainActivity.this, GameActivity.class);
			intent.putExtra("IsPlayback", false);
			startActivity(intent);
		}
	};

	AdapterView.OnItemClickListener OnItem = new AdapterView.OnItemClickListener()
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			Intent intent = new Intent(MainActivity.this, GameActivity.class);
			intent.putExtra("IsPlayback", true);
			intent.putExtra("Steps", kRecords.get(position).GetSteps());
			intent.putExtra("Outcome", kRecords.get(position).outcome.ordinal());
			startActivity(intent);
		}
	};

	private void ResetTable(boolean sortByTime)
	{
		kList.setAdapter(null);

		kRecords.clear();
		kRecords = kDB.Read();

		if (sortByTime)
		{
			Collections.sort(kRecords, new SortByTime());
		}
		else
		{
			Collections.sort(kRecords, new SortByTitle());
		}

		ArrayList<String> Items = new ArrayList<>();

		for (int i = 0; i < kRecords.size(); i++)
		{
			Items.add(kRecords.get(i).time + " - " + kRecords.get(i).title);
		}

		ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, Items);
		kList.setAdapter(adapter);
		kList.setOnItemClickListener(OnItem);
	}
}

class SortByTime implements Comparator
{
	@Override
	public int compare(Object o0, Object o1)
	{
		Record r0 = (Record) o0;
		Record r1 = (Record) o1;

		return -Integer.compare(r0.ID, r1.ID);
	}
}

class SortByTitle implements Comparator
{
	@Override
	public int compare(Object o0, Object o1)
	{
		Record r0 = (Record) o0;
		Record r1 = (Record) o1;

		return r0.title.compareTo(r1.title);
	}
}