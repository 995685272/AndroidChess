package com.example.chess;

import android.content.Context;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class KTLib
{
	final static int LightColor = Color.rgb(254, 206, 158);
	final static int HighColor = Color.rgb(208, 140, 71);

	final static int Border = Color.argb(255, 128, 128, 128);
	final static int Blue = Color.argb(255, 13, 113, 137);
	final static int Green = Color.argb(255, 107, 194, 90);
	final static int Red = Color.argb(255, 244, 60, 52);
	final static int Yellow = Color.argb(255, 252, 177, 52);

	static DisplayMetrics GetMetrics(Context context)
	{
		WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		DisplayMetrics dm = new DisplayMetrics();
		wm.getDefaultDisplay().getMetrics(dm);
		return dm;
	}

	static String GetTime()
	{
		SimpleDateFormat FullFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);// HH:mm:ss

		Date date = new Date(System.currentTimeMillis());
		return FullFormat.format(date);
	}
}