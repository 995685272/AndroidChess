package com.example.chess;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;

import androidx.appcompat.widget.AppCompatTextView;

public class Title extends AppCompatTextView
{
	public Title(Context context, int ID, boolean IsRow)
	{
		super(context);
		setId(generateViewId());

		setTypeface(null, Typeface.BOLD);
		setGravity(Gravity.CENTER);

		if (IsRow)
		{
			setText(String.valueOf(ID % 8));
		}
		else
		{
			setText(String.valueOf((char)('A' + ID % 8)));
		}
	}
}