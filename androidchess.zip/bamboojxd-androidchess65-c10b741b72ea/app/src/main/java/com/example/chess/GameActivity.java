package com.example.chess;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import static android.view.View.generateViewId;

public class GameActivity extends AppCompatActivity implements Delegate
{
	ArrayList<TextView> kTitles = new ArrayList<>();
	ArrayList<Grid> kGrids = new ArrayList<>();

	ConstraintLayout kLayout;
	int kGridSide;

	ArrayList<Piece> kBPieces = new ArrayList<>();
	ArrayList<Piece> kTPieces = new ArrayList<>();

	Piece kSelected = null;
	ArrayList<Point> kLegalMoves = new ArrayList<>();

	int kMover = 1;

	Button kResign;
	Button kDraw;
	Button kAI;
	Button kUndo;

	Piece kPiece;
	Point kLocation;
	boolean kMoved;
	PieceKind kKind;
	ArrayList<Point> kMoves = new ArrayList<>();

	Piece kDestPiece;

	Record kRecord;
	Database kDB;

	boolean kIsPlayback = false;

	Button kHiddenButton;
	Button kMenu;

	private final UIHandler mHandler = new UIHandler(this);

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.activity_game);

		kLayout = findViewById(R.id.SuperLayout);

		DisplayMetrics DM = KTLib.GetMetrics(this);
		kGridSide = (DM.widthPixels - 40 * 2) / 8;

		kRecord = new Record();

		Intent intent = getIntent();

		kIsPlayback = intent.getBooleanExtra("IsPlayback", true);
		kDB = new Database(this);

		if (kIsPlayback)
		{
			kRecord.SetSteps(intent.getStringExtra("Steps"));
			kRecord.SetOutcome(intent.getIntExtra("Outcome", Outcome.YellowMates.ordinal()));
		}
	}

	@Override
	protected void onResume()
	{
		super.onResume();

		AddTitles();
		LocateTitles();

		AddGrids();
		LocateGrids();

		AddPieces();
		LocatePieces();

		AddFunctions();

		if (kIsPlayback)
		{
			Playback();

			kResign.setEnabled(false);
			kDraw.setEnabled(false);
			kAI.setEnabled(false);
			kUndo.setEnabled(false);
			kMenu.setEnabled(false);
		}
	}

	private final View.OnClickListener OnGrid = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			Grid grid = (Grid) view;

			if (kSelected != null && IsValidMove(grid.col, grid.row))
			{
				//	Confirmed Move Here

				if (!kIsPlayback)
				{
					ArrayList<Point> thisStep = new ArrayList<>();
					thisStep.add(new Point(kSelected.col, kSelected.row));
					thisStep.add(new Point(grid.col, grid.row));
					kRecord.steps.add(thisStep);
				}

				kPiece = kSelected;
				kLocation = new Point(kPiece.col, kPiece.row);
				kMoved = kSelected.Moved;
				kKind = kSelected.Kind;
				kMoves.clear();
				kMoves.addAll(kSelected.LegalMoves);

				kDestPiece = null;

				kUndo.setEnabled(true);

				Recover();
				kSelected.MoveTo(grid.col, grid.row);

				if (IsChecked(-kSelected.side))
				{
					Toast.makeText(getBaseContext(), (kSelected.side == 1 ? "Yellow" : "Red") + " checks!", Toast.LENGTH_LONG).show();

					if (IsCheckMate(-kSelected.side))
					{
						if (!kIsPlayback)
						{
							kRecord.outcome = kSelected.side == 1 ? Outcome.YellowMates : Outcome.RedMates;
							EndWithText((kSelected.side == 1 ? "Yellow" : "Red") + " mates! Game Over!");
						}
					}
				}

				kSelected = null;

				kMover = -kMover;
			}
		}
	};

	private final View.OnClickListener OnPiece = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			Piece piece = (Piece) view;

			if (kMover == piece.side)
			{
				if (kSelected != null && kSelected.getId() == piece.getId())
				{
					Recover();
					kSelected = null;
				}
				else
				{
					Select(piece);
				}
			}
			else
			{
				if (kSelected != null && IsValidMove(piece.col, piece.row))
				{
					//	Confirmed capture here

					if (!kIsPlayback)
					{
						ArrayList<Point> thisStep = new ArrayList<>();
						thisStep.add(new Point(kSelected.col, kSelected.row));
						thisStep.add(new Point(piece.col, piece.row));
						kRecord.steps.add(thisStep);
					}

					kPiece = kSelected;
					kLocation = new Point(kPiece.col, kPiece.row);
					kMoved = kSelected.Moved;
					kKind = kSelected.Kind;
					kMoves.clear();
					kMoves.addAll(kSelected.LegalMoves);

					kDestPiece = piece;

					kUndo.setEnabled(true);

					if (piece.Kind == PieceKind.King)
					{
						if (!kIsPlayback)
						{
							kRecord.outcome = piece.side == 1 ? Outcome.RedMates : Outcome.YellowMates;
							EndWithText("Game Over, " + (piece.side == 1 ? "Red" : "Yellow") + " mates!");
						}
					}

					piece.captured = true;
					piece.setVisibility(View.INVISIBLE);

					Recover();
					kSelected.MoveTo(piece.col, piece.row);

					if (IsChecked(-kSelected.side))
					{
						Toast.makeText(getBaseContext(), (kSelected.side == 1 ? "Yellow" : "Red") + " checks!", Toast.LENGTH_LONG).show();

						if (IsCheckMate(-kSelected.side))
						{
							if (!kIsPlayback)
							{
								kRecord.outcome = kSelected.side == 1 ? Outcome.YellowMates : Outcome.RedMates;
								EndWithText((kSelected.side == 1 ? "Yellow" : "Red") + " mates! Game Over!");
							}
						}
					}

					kSelected = null;

					kMover = -kMover;
				}
			}
		}
	};

	private final View.OnClickListener OnHidden = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			String message = "";

			switch (kRecord.outcome)
			{
				case Init:
				{
					message = "Init.";
					break;
				}

				case YellowMates:
				{
					message = "Yellow mates. The playback ends.";
					break;
				}

				case YellowResign:
				{
					message = "Yellow resigns. The playback ends.";
					break;
				}

				case YellowDrawn:
				{
					message = "Yellow draws. The playback ends.";
					break;
				}

				case RedMates:
				{
					message = "Red mates. The playback ends.";
					break;
				}

				case RedResign:
				{
					message = "Red resigns. The playback ends.";
					break;
				}

				case RedDrawn:
				{
					message = "Red draws. The playback ends.";
					break;
				}
			}

			Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG).show();
			Reset();
		}
	};

	private final View.OnClickListener OnMenu = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			finish();
		}
	};

	private void AddFunctions()
	{
		kResign = new Button(this);
		kResign.setId(generateViewId());
		kResign.setOnClickListener(OnResign);
		kResign.setText(R.string.Resign);
		kResign.setTypeface(null, Typeface.BOLD);
		kResign.setTextSize(10);
		kResign.setGravity(Gravity.CENTER);
		kResign.setAllCaps(false);
		kLayout.addView(kResign, (int) (kGridSide * 1.5), 100);

		kDraw = new Button(this);
		kDraw.setId(generateViewId());
		kDraw.setOnClickListener(OnDraw);
		kDraw.setText(R.string.Draw);
		kDraw.setTypeface(null, Typeface.BOLD);
		kDraw.setTextSize(10);
		kDraw.setGravity(Gravity.CENTER);
		kDraw.setAllCaps(false);
		kLayout.addView(kDraw, (int) (kGridSide * 1.5), 100);

		kAI = new Button(this);
		kAI.setId(generateViewId());
		kAI.setOnClickListener(OnAI);
		kAI.setText(R.string.AI);
		kAI.setTypeface(null, Typeface.BOLD);
		kAI.setTextSize(10);
		kAI.setGravity(Gravity.CENTER);
		kAI.setAllCaps(false);
		kLayout.addView(kAI, (int) (kGridSide * 1.5), 100);

		kUndo = new Button(this);
		kUndo.setId(generateViewId());
		kUndo.setText(R.string.Undo);
		kUndo.setOnClickListener(OnUndo);
		kUndo.setTypeface(null, Typeface.BOLD);
		kUndo.setTextSize(10);
		kUndo.setGravity(Gravity.CENTER);
		kUndo.setEnabled(false);
		kUndo.setAllCaps(false);
		kLayout.addView(kUndo, (int) (kGridSide * 1.5), 100);

		kMenu = new Button(this);
		kMenu.setId(generateViewId());
		kMenu.setOnClickListener(OnMenu);
		kMenu.setText(R.string.Menu);
		kMenu.setTypeface(null, Typeface.BOLD);
		kMenu.setTextSize(10);
		kMenu.setGravity(Gravity.CENTER);
		kMenu.setAllCaps(false);
		kLayout.addView(kMenu, kGridSide * 2, 100);

		kHiddenButton = new Button(this);
		kHiddenButton = new Button(this);
		kHiddenButton.setId(generateViewId());
		kHiddenButton.setOnClickListener(OnHidden);
		kHiddenButton.setVisibility(View.INVISIBLE);
		kLayout.addView(kHiddenButton);

		ConstraintLayout kLayout = GetLayout();

		ConstraintSet set = new ConstraintSet();
		set.clone(kLayout);

		set.connect(kResign.getId(), ConstraintSet.LEFT, kTitles.get(24).getId(), ConstraintSet.LEFT);
		set.connect(kResign.getId(), ConstraintSet.TOP, kTitles.get(24).getId(), ConstraintSet.BOTTOM);

		set.connect(kDraw.getId(), ConstraintSet.LEFT, kTitles.get(26).getId(), ConstraintSet.LEFT);
		set.connect(kDraw.getId(), ConstraintSet.TOP, kTitles.get(26).getId(), ConstraintSet.BOTTOM);

		set.connect(kAI.getId(), ConstraintSet.LEFT, kTitles.get(28).getId(), ConstraintSet.LEFT);
		set.connect(kAI.getId(), ConstraintSet.TOP, kTitles.get(28).getId(), ConstraintSet.BOTTOM);

		set.connect(kUndo.getId(), ConstraintSet.LEFT, kTitles.get(30).getId(), ConstraintSet.LEFT);
		set.connect(kUndo.getId(), ConstraintSet.TOP, kTitles.get(30).getId(), ConstraintSet.BOTTOM);

		set.connect(kMenu.getId(), ConstraintSet.LEFT, kGrids.get(3).getId(), ConstraintSet.LEFT);
		set.connect(kMenu.getId(), ConstraintSet.TOP, kResign.getId(), ConstraintSet.BOTTOM);
		set.setMargin(kMenu.getId(), 3, 50);

		set.applyTo(kLayout);
	}

	private final View.OnClickListener OnResign = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			kRecord.outcome = kMover == 1 ? Outcome.YellowResign : Outcome.RedResign;
			EndWithText("Resigned. Game Over!");
		}
	};

	private final View.OnClickListener OnDraw = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			kRecord.outcome = kMover == 1 ? Outcome.YellowDrawn : Outcome.RedDrawn;
			EndWithText("Drawn. Game Over!");
		}
	};

	private final View.OnClickListener OnAI = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			ArrayList<Piece> SidePieces = GetSidePieces(kMover);
			ArrayList<Piece> Candidates = new ArrayList<>();

			for (int i = 0; i < SidePieces.size(); i++)
			{
				if (SidePieces.get(i).GetRealLegalMoves().size() != 0)
				{
					Candidates.add(SidePieces.get(i));
				}
			}

			if (Candidates.size() == 0)
			{
				Toast.makeText(getBaseContext(), "No piece can be moved.", Toast.LENGTH_LONG).show();
				return;
			}

			int seed = (int) (Math.random() * 10);

			Piece Candidate = Candidates.get(seed % Candidates.size());

			ArrayList<Point> RealLegalMoves = Candidate.GetRealLegalMoves();

			Point Destination = RealLegalMoves.get(seed % RealLegalMoves.size());

			Candidate.callOnClick();

			for (int i = 0; i < kLegalMoves.size(); i++)
			{
				Recover(kLegalMoves.get(i).x, kLegalMoves.get(i).y);
			}

			Tick(Destination.x, Destination.y, KTLib.Blue);

			DelayClick(Destination.x, Destination.y);
		}
	};

	private final View.OnClickListener OnUndo = new View.OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			kUndo.setEnabled(false);

			kPiece.MoveTo(kLocation.x, kLocation.y);
			kPiece.Moved = kMoved;
			kPiece.Kind = kKind;

			if (kKind == PieceKind.Pawn)
			{
				kPiece.setBackground(getResources().getDrawable(-kMover > 0 ? R.drawable.pawn0 : R.drawable.pawn1, null));
			}

			kPiece.LegalMoves.clear();
			kPiece.LegalMoves.addAll(kMoves);

			if (kDestPiece != null)
			{
				kDestPiece.setVisibility(View.VISIBLE);
				kDestPiece.captured = false;
			}

			if (kRecord.steps.size() != 0)
			{
				kRecord.steps.remove(kRecord.steps.size() - 1);
			}

			kMover = -kMover;
		}
	};

	private void AddTitles()
	{
		kTitles.clear();

		for (int i = 0; i < 16; i++)
		{
			Title title = new Title(this, i, true);
			kLayout.addView(title, 40, kGridSide);

			kTitles.add(title);
		}

		for (int i = 0; i < 16; i++)
		{
			Title title = new Title(this, i, false);
			kLayout.addView(title, kGridSide, 40);

			kTitles.add(title);
		}
	}

	private void LocateTitles()
	{
		ConstraintSet set = new ConstraintSet();
		set.clone(kLayout);

		for (int i = 0; i < 8; i++)
		{
			set.connect(kTitles.get(i).getId(), ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START);
			if (i == 7)
			{
				set.connect(kTitles.get(i).getId(), ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP);
				set.setMargin(kTitles.get(i).getId(), 3, 40);
			}
			else
			{
				set.connect(kTitles.get(i).getId(), ConstraintSet.TOP, kTitles.get(i + 1).getId(), ConstraintSet.BOTTOM);
			}
		}

		for (int i = 8; i < 16; i++)
		{
			set.connect(kTitles.get(i).getId(), ConstraintSet.RIGHT, ConstraintSet.PARENT_ID, ConstraintSet.RIGHT);
			if (i == 15)
			{
				set.connect(kTitles.get(i).getId(), ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP);
				set.setMargin(kTitles.get(i).getId(), 3, 40);
			}
			else
			{
				set.connect(kTitles.get(i).getId(), ConstraintSet.TOP, kTitles.get(i + 1).getId(), ConstraintSet.BOTTOM);
			}
		}

		for (int i = 16; i < 24; i++)
		{
			set.connect(kTitles.get(i).getId(), ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP);
			if (i == 16)
			{
				set.connect(kTitles.get(i).getId(), ConstraintSet.LEFT, kTitles.get(0).getId(), ConstraintSet.RIGHT);
			}
			else
			{
				set.connect(kTitles.get(i).getId(), ConstraintSet.LEFT, kTitles.get(i - 1).getId(), ConstraintSet.RIGHT);
			}
		}

		for (int i = 24; i < 32; i++)
		{
			set.connect(kTitles.get(i).getId(), ConstraintSet.TOP, kTitles.get(0).getId(), ConstraintSet.BOTTOM);
			if (i == 24)
			{
				set.connect(kTitles.get(i).getId(), ConstraintSet.LEFT, kTitles.get(0).getId(), ConstraintSet.RIGHT);
			}
			else
			{
				set.connect(kTitles.get(i).getId(), ConstraintSet.LEFT, kTitles.get(i - 1).getId(), ConstraintSet.RIGHT);
			}
		}

		set.applyTo(kLayout);
	}

	private void AddGrids()
	{
		kGrids.clear();

		for (int i = 0; i < 64; i++)
		{
			Grid grid = new Grid(this, i);
			grid.setOnClickListener(OnGrid);
			kLayout.addView(grid, kGridSide, kGridSide);

			kGrids.add(grid);
		}
	}

	private void LocateGrids()
	{
		ConstraintSet set = new ConstraintSet();
		set.clone(kLayout);

		for (int i = 0; i < 64; i++)
		{
			if (i % 8 == 0)
			{
				set.connect(kGrids.get(i).getId(), ConstraintSet.LEFT, kTitles.get(0).getId(), ConstraintSet.RIGHT);
			}
			else
			{
				set.connect(kGrids.get(i).getId(), ConstraintSet.LEFT, kGrids.get(i - 1).getId(), ConstraintSet.RIGHT);
			}

			if (i / 8 == 7)
			{
				set.connect(kGrids.get(i).getId(), ConstraintSet.TOP, kTitles.get(16).getId(), ConstraintSet.BOTTOM);
			}
			else
			{
				set.connect(kGrids.get(i).getId(), ConstraintSet.TOP, kGrids.get(i + 8).getId(), ConstraintSet.BOTTOM);
			}
		}

		set.applyTo(kLayout);
	}

	private void AddPieces()
	{
		for (int i = 0; i < 8; i++)
		{
			Pawn pawn0 = new Pawn(this, 1, PieceKind.Pawn, this);
			pawn0.setOnClickListener(OnPiece);
			kLayout.addView(pawn0, kGridSide, kGridSide);
			kBPieces.add(pawn0);

			Pawn pawn1 = new Pawn(this, -1, PieceKind.Pawn, this);
			pawn1.setOnClickListener(OnPiece);
			kLayout.addView(pawn1, kGridSide, kGridSide);
			kTPieces.add(pawn1);
		}

		for (int i = 0; i < 2; i++)
		{
			Piece rook0 = new Piece(this, 1, PieceKind.Rook, this);
			rook0.setOnClickListener(OnPiece);
			kLayout.addView(rook0, kGridSide, kGridSide);
			kBPieces.add(rook0);

			Piece rook1 = new Piece(this, -1, PieceKind.Rook, this);
			rook1.setOnClickListener(OnPiece);
			kLayout.addView(rook1, kGridSide, kGridSide);
			kTPieces.add(rook1);

			Piece knight0 = new Piece(this, 1, PieceKind.Knight, this);
			knight0.setOnClickListener(OnPiece);
			kLayout.addView(knight0, kGridSide, kGridSide);
			kBPieces.add(knight0);

			Piece knight1 = new Piece(this, -1, PieceKind.Knight, this);
			knight1.setOnClickListener(OnPiece);
			kLayout.addView(knight1, kGridSide, kGridSide);
			kTPieces.add(knight1);

			Piece bishop0 = new Piece(this, 1, PieceKind.Bishop, this);
			bishop0.setOnClickListener(OnPiece);
			kLayout.addView(bishop0, kGridSide, kGridSide);
			kBPieces.add(bishop0);

			Piece bishop1 = new Piece(this, -1, PieceKind.Bishop, this);
			bishop1.setOnClickListener(OnPiece);
			kLayout.addView(bishop1, kGridSide, kGridSide);
			kTPieces.add(bishop1);
		}

		Piece queen0 = new Piece(this, 1, PieceKind.Queen, this);
		queen0.setOnClickListener(OnPiece);
		kLayout.addView(queen0, kGridSide, kGridSide);
		kBPieces.add(queen0);

		Piece queen1 = new Piece(this, -1, PieceKind.Queen, this);
		queen1.setOnClickListener(OnPiece);
		kLayout.addView(queen1, kGridSide, kGridSide);
		kTPieces.add(queen1);

		Piece king0 = new Piece(this, 1, PieceKind.King, this);
		king0.setOnClickListener(OnPiece);
		kLayout.addView(king0, kGridSide, kGridSide);
		kBPieces.add(king0);

		Piece king1 = new Piece(this, -1, PieceKind.King, this);
		king1.setOnClickListener(OnPiece);
		kLayout.addView(king1, kGridSide, kGridSide);
		kTPieces.add(king1);
	}

	private void LocatePieces()
	{
		//	Locate Pawns
		for (int i = 0; i < 8; i++)
		{
			kBPieces.get(i).InitLocation(i, 1);
			kTPieces.get(i).InitLocation(i, 6);
		}

		for (int i = 8; i < 11; i++)
		{
			kBPieces.get(i).InitLocation(i % 8, 0);
			kTPieces.get(i).InitLocation(i % 8, 7);
		}

		for (int i = 11; i < 14; i++)
		{
			kBPieces.get(i).InitLocation(7 - i % 11, 0);
			kTPieces.get(i).InitLocation(7 - i % 11, 7);
		}

		kBPieces.get(14).InitLocation(3, 0);
		kTPieces.get(14).InitLocation(3, 7);

		kBPieces.get(15).InitLocation(4, 0);
		kTPieces.get(15).InitLocation(4, 7);
	}

	private boolean IsValidMove(int col, int row)
	{
		for (int i = 0; i < kLegalMoves.size(); i++)
		{
			if (col == kLegalMoves.get(i).x && row == kLegalMoves.get(i).y)
			{
				return true;
			}
		}

		return false;
	}

	private ArrayList<Piece> GetSidePieces(int side)
	{
		ArrayList<Piece> SidePieces = new ArrayList<>();

		ArrayList<Piece> AllPieces = new ArrayList<>();
		AllPieces.addAll(kBPieces);
		AllPieces.addAll(kTPieces);

		for (int i = 0; i < AllPieces.size(); i++)
		{
			if (AllPieces.get(i).side == side && !AllPieces.get(i).captured)
			{
				SidePieces.add(AllPieces.get(i));
			}
		}

		return SidePieces;
	}

	private void Select(Piece piece)
	{
		Recover();

		kSelected = piece;

		Tick(piece.col, piece.row, KTLib.Yellow);

		if (piece.Kind != PieceKind.Pawn)
		{
			kLegalMoves = piece.GetRealLegalMoves();
		}
		else
		{
			Pawn pawn = (Pawn) piece;
			kLegalMoves = pawn.GetRealLegalMoves();
		}

		Tick(kLegalMoves);
	}

	private void Recover()
	{
		if (kSelected != null)
		{
			Recover(kSelected.col, kSelected.row);
		}

		for (int i = 0; i < kLegalMoves.size(); i++)
		{
			Recover(kLegalMoves.get(i).x, kLegalMoves.get(i).y);
		}

		kLegalMoves.clear();
	}

	private void Recover(int col, int row)
	{
		kGrids.get(row * 8 + col).Recover();
	}

	private void Tick(ArrayList<Point> Points)
	{
		for (int i = 0; i < Points.size(); i++)
		{
			Tick(Points.get(i).x, Points.get(i).y, KTLib.Green);
		}
	}

	private void Tick(int col, int row, int fill)
	{
		kGrids.get(row * 8 + col).SetSelected(fill);
	}

	public ArrayList<Point> GetAllMoves(int side)
	{
		ArrayList<Piece> SidePieces = GetSidePieces(side);
		ArrayList<Point> AllMoves = new ArrayList<>();

		for (int i = 0; i < SidePieces.size(); i++)
		{
			AllMoves.addAll(SidePieces.get(i).GetLegalMoves());
		}

		return AllMoves;
	}

	private boolean IsCheckMate(int side)
	{
		ArrayList<Piece> SidePieces = GetSidePieces(side);

		for (int i = 0; i < SidePieces.size(); i++)
		{
			Piece candidate = SidePieces.get(i);
			int OriginX = candidate.col;
			int OriginY = candidate.row;

			ArrayList<Point> RealLegalMoves = candidate.GetRealLegalMoves();

			for (int j = 0; j < RealLegalMoves.size(); j++)
			{
				candidate.col = RealLegalMoves.get(j).x;
				candidate.row = RealLegalMoves.get(j).y;

				if (!candidate.IsChecked(candidate.side))
				{
					candidate.col = OriginX;
					candidate.row = OriginY;

					return false;
				}
			}

			candidate.col = OriginX;
			candidate.row = OriginY;
		}

		return true;
	}

	@Override
	public boolean IsChecked(int side)
	{
		ArrayList<Point> AllOpponentMoves = GetAllMoves(-side);

		Piece king = side == 1 ? kBPieces.get(15) : kTPieces.get(15);

		for (int i = 0; i < AllOpponentMoves.size(); i++)
		{
			if (AllOpponentMoves.get(i).x == king.col && AllOpponentMoves.get(i).y == king.row)
			{
				return true;
			}
		}

		return false;
	}

	@Override
	public Piece GetAliveOccupant(int col, int row)
	{
		for (int i = 0; i < 16; i++)
		{
			if (kTPieces.get(i).col == col && kTPieces.get(i).row == row && !kTPieces.get(i).captured)
			{
				return kTPieces.get(i);
			}

			if (kBPieces.get(i).col == col && kBPieces.get(i).row == row && !kBPieces.get(i).captured)
			{
				return kBPieces.get(i);
			}
		}

		return null;
	}

	@Override
	public int GetGridID(int col, int row)
	{
		return kGrids.get(row * 8 + col).getId();
	}

	@Override
	public ConstraintLayout GetLayout()
	{
		return findViewById(R.id.SuperLayout);
	}

	private void Playback()
	{
		new Playback().start();
	}

	private class Playback extends Thread
	{
		public void run()
		{
			super.run();

			for (int i = 0; i < kRecord.steps.size(); i++)
			{
				int col = kRecord.steps.get(i).get(0).x;
				int row = kRecord.steps.get(i).get(0).y;

				Piece occupant = GetAliveOccupant(col, row);

				Message message = new Message();
				message.what = occupant != null ? occupant.getId() : kGrids.get(row * 8 + col).getId();
				mHandler.sendMessage(message);

				SystemClock.sleep(1000);

				col = kRecord.steps.get(i).get(1).x;
				row = kRecord.steps.get(i).get(1).y;

				occupant = GetAliveOccupant(col, row);

				message = new Message();
				message.what = occupant != null ? occupant.getId() : kGrids.get(row * 8 + col).getId();
				mHandler.sendMessage(message);

				SystemClock.sleep(1000);
			}

			Message message = new Message();
			message.what = kHiddenButton.getId();
			mHandler.sendMessage(message);
		}
	}

	private void DelayClick(int col, int row)
	{
		new DelayedClick(col, row).start();
	}

	private static class UIHandler extends Handler
	{
		private final WeakReference<GameActivity> mActivity;

		private UIHandler(GameActivity activity)
		{
			mActivity = new WeakReference<>(activity);
		}

		@Override
		public void handleMessage(Message message)
		{
			GameActivity activity = mActivity.get();
			if (activity != null)
			{
				activity.findViewById(message.what).callOnClick();
			}
		}
	}

	private class DelayedClick extends Thread
	{
		private final int col;
		private final int row;

		private DelayedClick(int col, int row)
		{
			this.col = col;
			this.row = row;
		}

		public void run()
		{
			super.run();

			SystemClock.sleep(1000);

			Piece occupant = GetAliveOccupant(col, row);

			Message message = new Message();
			message.what = occupant != null ? occupant.getId() : kGrids.get(row * 8 + col).getId();

			mHandler.sendMessage(message);
		}
	}

	private void EndWithText(String message)
	{
		Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG).show();

		final EditText titlePrompt = new EditText(this);
		titlePrompt.setFocusable(true);

		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setCancelable(false);
		builder.setTitle(getString(R.string.AskRecord));
		builder.setView(titlePrompt);
		builder.setNegativeButton(getString(R.string.Cancel),
				new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int which)
					{
						Toast.makeText(getBaseContext(), "Cancelled.", Toast.LENGTH_LONG).show();
						Reset();
					}
				});
		builder.setPositiveButton(getString(R.string.Save),
				new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int which)
					{
						if (titlePrompt.getText().toString().length() == 0)
						{
							kRecord.title = "Null Name";
						}
						else
						{
							kRecord.title = titlePrompt.getText().toString();
						}
						kDB.InsertRecord(kRecord);
						Toast.makeText(getBaseContext(), "Saved.", Toast.LENGTH_LONG).show();
						Reset();
					}
				});
		builder.show();
	}

	private void Reset()
	{
		kLayout.removeAllViews();

		kTitles.clear();
		kGrids.clear();

		kBPieces.clear();
		kTPieces.clear();

		kSelected = null;
		kLegalMoves.clear();

		kMover = 1;

		kResign = null;
		kDraw = null;
		kAI = null;
		kUndo = null;

		kRecord.steps.clear();

		kMoves.clear();

		kIsPlayback = false;

		AddTitles();
		LocateTitles();

		AddGrids();
		LocateGrids();

		AddPieces();
		LocatePieces();

		AddFunctions();
	}
}