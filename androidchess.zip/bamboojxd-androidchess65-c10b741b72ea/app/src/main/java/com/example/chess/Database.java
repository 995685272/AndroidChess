package com.example.chess;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

class Database
{
	private final SQLiteDatabase kDB;

	Database(Context context)
	{
		DBHelper dbHelper = new DBHelper(context, "Chess.db", 1);
		kDB = dbHelper.getWritableDatabase();
	}

	void InsertRecord(Record record)
	{
		kDB.execSQL("insert into Records(title, dateTime, steps, outcome) values(?, ? ,? ,? )", new String[]{record.title, KTLib.GetTime(), record.GetSteps(), record.GetOutcome()});
	}

	ArrayList<Record> Read()
	{
		ArrayList<Record> Records = new ArrayList<>();

		Cursor cursor =  kDB.rawQuery("select * from Records", null);

		while (cursor.moveToNext())
		{
			int ID = cursor.getInt(cursor.getColumnIndex("rid"));
			String title = cursor.getString(cursor.getColumnIndex("title"));
			String time = cursor.getString(cursor.getColumnIndex("dateTime"));
			String steps = cursor.getString(cursor.getColumnIndex("steps"));
			int outcome = cursor.getInt(cursor.getColumnIndex("outcome"));

			Record SingleRecord = new Record();
			SingleRecord.ID = ID;
			SingleRecord.title = title;
			SingleRecord.time = time;
			SingleRecord.SetSteps(steps);
			SingleRecord.SetOutcome(outcome);

			Records.add(SingleRecord);
		}

		cursor.close();

		return Records;
	}
}