package com.example.chess;

public enum Outcome
{
	Init,
	YellowMates,
	RedMates,
	YellowResign,
	RedResign,
	YellowDrawn,
	RedDrawn;
}