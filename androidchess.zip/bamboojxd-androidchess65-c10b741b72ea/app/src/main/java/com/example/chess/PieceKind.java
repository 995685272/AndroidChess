package com.example.chess;

public enum PieceKind
{
	Pawn,
	Rook,
	Knight,
	Bishop,
	Queen,
	King;
}